@extends('layouts/layout')

@section('content')
	<h1>Final Project</h1>
	<h4>Vien, Alex, Anh</h4>
@endsection
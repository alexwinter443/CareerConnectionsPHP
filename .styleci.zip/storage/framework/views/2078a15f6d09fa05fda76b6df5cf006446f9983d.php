<?php $__env->startSection('content'); ?>

	<h3>Admin Management Tool</h3>
	<a href="">Manage User</a><br>
	<a href="createGroup">Create new Group</a><br>
	<a href="adminViewGroup">View Groups</a>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Alexv\Documents\1.LaravelWorkspace\MilestonePHP3\resources\views/internals/admin.blade.php ENDPATH**/ ?>
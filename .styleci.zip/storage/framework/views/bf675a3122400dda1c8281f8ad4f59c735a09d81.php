Greetings,
<p><?php echo e($body); ?> </p>


<p>Repectfully,  <?php echo e($signature); ?></p>

<?php /**PATH C:\Users\Alexv\Documents\1.LaravelWorkspace\MilestonePHP3\resources\views/sendEmail.blade.php ENDPATH**/ ?>